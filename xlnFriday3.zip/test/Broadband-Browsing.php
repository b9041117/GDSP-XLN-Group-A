<?php 

session_start();

	include("connection.php");
	include("functions.php");
    include("Details.php");

    $conn = mysqli_connect("localhost","root","","xln");
    
    $Customer_Key = intval($Customer_Key);
    echo $Customer_Key;

    if(isset($_POST['BBR_Description']))
    {
        $data=$_POST['BBR_Description'];
        $fp = fopen('BBR_Description.txt', 'a');
        fwrite($fp, $data);
        fclose($fp);
    }

    ?>

<!DOCTYPE html> 
<html lang"=en">
    <head>
        <link rel="stylesheet" href="troubleshooting.css">
        <script src="myScript.js"></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> XLN Troubleshooting Steps-BroadBand (NoSync)</title>
    </head>
    <body>
    <div id="stickybar">
            <script src="myScript.js"></script>
            <a class="logo"><img src="https://upload.wikimedia.org/wikipedia/commons/6/6d/XLN-Logo.jpg" alt="image not loaded" height="100" width=aut0></a>
            <p class = "sales"> Sales: <br> 0808 302 9676 </p>
            <p class = "customer"> Customer Service: <br> 0344 880 7777</p>
        </div>

        <div class="upnav" id="myupnav">
            <li><a href="#">Our Products</a></li>
            <li><a href="#">Why XLN</a></li>
            <li><a href="#">Support</a></li>
            <li><a href="#">My Account</a></li>
        </div>

        <ul class="topnav">
            <li><a href="https://www.xln.co.uk/business-phone">Phone</a></li>
            <li><a href="https://www.xln.co.uk/business-broadband-deals/offers">Broadband</a></li>
            <li><a href="https://www.xln.co.uk/business-fibre">Fibre</a></li>
            <li><a href="https://www.xln.co.uk/cloud-voice">Cloud Voice</a></li>
            <li><a href="https://www.xln.co.uk/business-mobile">Mobile</a></li>
            <li><a href="https://www.xln.co.uk/wi-fi">WiFi</a></li>
            <li><a href="https://www.xln.co.uk/pay">Payments</a></li>
            <li><a href="https://www.xln.co.uk/energy">Energy</a></li>
        </ul>

        <br><br>

        <h1>Broadband Troubleshooting</h1>

        <div id="part1" style="display: block;">
            
            <div class="form">
                <form>
                    <p id="one">Step 1: Is your telephone line working? <br> <br> </p>
               
                    <input type="text" placeholder="Description of problem" id="problem" name="BBR_Description" required>
                    <br>
                    <br>
                    <label>Are you only able to make calls? (Please select no if its only outgoing calls)</label><br>
                    <br>
                    <button onclick="return showHide('part1', 'part2')">Yes</button>
                    <button onclick="return showHide('part1', 'part3')">No</button>
                    <br>
                </form>
            </div>
        </div>
        
        <div id="part2" style="display: none;">
            <div class="form">
                <form>
                    <p id="two"> Remove WiFi booster and network switch. Is the problem fixed? </p></h4>
                    <a class ="socket"><img src="https://primex.com/wp-content/uploads/2019/04/blog-network-switch.jpg" alt="socket" height=300 width =300></a>
                    
                    <br><br>
                    <button onclick="return showHide('part2', 'part4')">Yes</button>
                    <button onclick="return showHide('part2', 'part5')">No</button>
                    <br>
                </form>
            </div>    
        </div>
        
        <div id="part3" style="display:none;">
            <div class="form">
                <form>
                    
                    <label for="numWorked">Try dialling 17070. If unsuccessful; Is 17070 number the correct number?</label>
                    <br>
                    <br>
                    <button onclick="return showHide('part3', 'part2')">Yes</button>
                    <button onclick="return showHide('part3', 'SwitchLandLineCrossedLine')">No</button>
                </form>
            </div>
        </div>
        

        <div id="part4" style="display: none;">
            <div class="form">
                <form>
                    <h1>   <br>End of troubleshooting steps.    </h1>
                    <p id ="one"> Do you require further assistance?</p>
                    <br><br>
                    <input type="button" id="button" onclick="window.location.href='Callout.php';" value="Yes" />
                    <button onclick="return showHide('part4', 'part8')">No</button>
                    <br>
                </form>
            </div>    
        </div>

        <div id="part5" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Does This Website Load?<br> <br> <a href = "https://www.xln.co.uk/myaccount">Link </a></p>
                    <br><br>
                    <button onclick="return showHide('part5', 'part4')">Yes</button>
                    <button onclick="return showHide('part5', 'part7')">No</button>
                    <br>
                </form>
            </div>    
        </div>

        <div id="part7" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Anything connected to redport? If so disconnect.</p>
                    <br><br>
                    <button onclick="return showHide('part7', 'part8')">Next</button>
                    <br>
                </form>
            </div>    
        </div>

        <div id="part8" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Have you done a factory reset?<br> <br> Is the problem fixed?</p>
                    <br><br>
                    <button onclick="return showHide('part8', 'part4')">Yes</button>
                    <button onclick="return showHide('part8', 'part9')">No</button>
                   
                    <br>
                </form>
            </div>    
        </div>

        <div id="SwitchLandLineCrossedLine" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Please try using the Landline troubleshoot<br> <br></p>
                    <br><br>
                    <input type="button" id="button" onclick="window.location.href='LandlineTroubleshoot.php';" value="Okay" />
                    <br>
                </form>
            </div>    
        </div>

        <div id="part9" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Is the issue occuring on other devices aswell? Wired & Wireless?</p>
                    <br><br>
                    <button onclick="return showHide('part9', 'part10')">Yes</button>
                    <button onclick="return showHide('part9', 'part10')">No</button>
                    <br>
                </form>
            </div>    
        </div>

        <div id="part10" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Can you reach router page? <br><br><a href = "http://192.168.1.1/" target ="_blank">Link </a></p>
                    <br><br>
                    <button onclick="return showHide('part10', 'part4')">Yes</button>
                    <button onclick="return showHide('part10', 'part11')">No</button>
                
                    <br>
                </form>
            </div>    
        </div>

        <div id="part11" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Try alternative router. Fixed?<br> <br></p>
                    <br><br>
                    <button onclick="return showHide('part11', 'part18')">Yes</button>
                    <button onclick="return showHide('part11', 'part14')">No</button>

                    <br>
                </form>
            </div>    
        </div>

        <div id="part14" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one"> Time related charges -  (Not applicable if you have our Bussiness assurance package) <br> <br></p>
                    <br><br>
                    <p id = "one"> £165 + VAT callout charge and for first hour, then an additional £65 + VAT p/h.</p>
                    <br><br>
                    <button onclick="return showHide('part14', 'part15')">Next</button>
                    <br>
                </form>
            </div>    
        </div>

        <div id="part15" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Access Times<br> <br></p>
                    <br><br>
                    <p>Please enter your desired date (format DD/MM/YYYY) for an engineer along with AM/PM slot choice</p>
                    <br><br>
                    <p>AM slot is between 8am-1pm   &   PM slot is between 1pm-6PM</p>
                    <br><br>
                    <input type="text" placeholder="please enter date and session slot" id="problem" required>
                    <br><br>
                    <button onclick="return showHide('part15', 'part16')">Next</button>
                    <br>
                </form>
            </div>    
        </div>

        <div id="part16" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Missed appointment fee<br> <br></p>
                    <br><br>
                    <p id = "one"> There will be a £99 + VAT charge for any missed appoinments. </p>
                    <br><br>
                    <input type="button" id="button" onclick="window.location.href='Callout.php';" value="Next" />
                    <br>
                </form>
            </div>    
        </div>

        <div id="part17" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">SLA <br> <br>Display user care level</p>
                    <br><br>
                    <button onclick="return showHide('part17', 'part4')">Next</button>
                    <br>
                </form>
            </div>    
        </div>

        <div id="part18" style="display: none;">
            <div class="form">
                <form>
                    <p id ="one">Thank you for choosing XLN </p>
                    <br><br>
                    <br>
                </form>
            </div>    
        </div>

        <footer class="footer">
            <p id ="footer"> Copyright XLN 2021 </p>
        </footer>



    </body>
</html>