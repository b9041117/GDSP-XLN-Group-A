<?php include("Form.php");
include("CustomerKey.php");
include("Details.php");
include("connection.php"); 
?>

<?php if(!empty($statusMsg)){ ?>
    <p class="statusMsg <?php echo !empty($msgClass)?$msgClass:''; ?>"><?php echo $statusMsg; ?></p>
<?php } ?>


<!DOCTYPE html> 
<html lang"=en">
    <head>
        <link rel="stylesheet" href="troubleshooting.css"
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> XLN Troubleshooting Steps</title>
    </head>
    <body>
        <div id="stickybar">
            <script src="myScript.js"></script>
            <a class="logo" href ="http://www.xln.co.uk"><img src="https://upload.wikimedia.org/wikipedia/commons/6/6d/XLN-Logo.jpg" alt="image not loaded" height="100" width=auto ></a>
            <p class = "sales"> Sales: <br> 0808 302 9676 </p>
            <p class = "customer"> Customer Service: <br> 0344 880 7777</p>
        </div>

        <div class="upnav" id="myupnav">
            <li><a href="#">Our Products</a></li>
            <li><a href="#">Why XLN</a></li>
            <li><a href="#">Support</a></li>
            <li><a href="#">My Account</a></li>
        </div>

        <ul class="topnav">
            <li><a href="https://www.xln.co.uk/business-phone">Phone</a></li>
            <li><a href="https://www.xln.co.uk/business-broadband-deals/offers">Broadband</a></li>
            <li><a href="https://www.xln.co.uk/business-fibre">Fibre</a></li>
            <li><a href="https://www.xln.co.uk/cloud-voice">Cloud Voice</a></li>
            <li><a href="https://www.xln.co.uk/business-mobile">Mobile</a></li>
            <li><a href="https://www.xln.co.uk/wi-fi">WiFi</a></li>
            <li><a href="https://www.xln.co.uk/pay">Payments</a></li>
            <li><a href="https://www.xln.co.uk/energy">Energy</a></li>
        </ul>

            <div class="column1">


                <h1>   <br> Callout Information    </h1>


            <!-- Display submission status -->


<!-- Display contact form -->
<form method="post" action="" enctype="multipart/form-data">
    <div class="form-group">
        <input type="text" name="name" class="form-control" value="<?php echo !empty($postData['name'])?$postData['name']:''; ?>" placeholder="Name" required="">
    </div>
    <br>
    <div class="form-group">
        <input type="email" name="email" class="form-control" value="<?php echo !empty($postData['email'])?$postData['email']:''; ?>" placeholder="Email address" required="">
    </div>
    <br>
    <div class="form-group">
        <input type="text" name="subject" class="form-control" value="<?php echo !empty($postData['subject'])?$postData['subject']:''; ?>" placeholder="Subject" required="">
    </div>
    <br>
    <div class="form-group">
        <textarea name="message" class="form-control" placeholder="Write your message here" required=""><?php echo !empty($postData['message'])?$postData['message']:''; ?></textarea>
    </div>
    <br>
    <div class="form-group">
        <input type="file" name="attachment" class="form-control">
    </div>
    <br>
    <div class="submit">
        <br>
        <input type="submit" name="submit" id="button" class="btn" value="SUBMIT">
    </div>
</form> 
</div>

<footer class="footer">
                <p id ="footer"> Copyright XLN 2021 </p>
            </footer>
            
          

    </body>
</html>