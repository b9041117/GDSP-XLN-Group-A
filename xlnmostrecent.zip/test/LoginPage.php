<?php 

session_start();

	include("connection.php");
	include("functions.php");

	if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$Customer_Key= $_POST['Customer_Key'];
		
		if(!empty($Customer_Key) && is_numeric($Customer_Key))
		{

			//read from database
			$query = "select * from users where Customer_Key = '$Customer_Key' limit 1";
			$result = mysqli_query($con, $query);
				
			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($_SESSION['Customer_Key'] = $user_data['Customer_Key'])
					{

						echo "Login Successful";

						$Customer_Key_Export = $Customer_Key;
					
						$var_str = var_export($Customer_Key_Export, true);
						$var = "<?php\n\n\$Customer_Key = $var_str;\n\n?>";
						file_put_contents('CustomerKey.php', $var);

						header("Location: IssueSelection.html");
						die;
					}
				}
			}
			
			$message = "Incorrect Customer Key";
			echo "<script type='text/javascript'>alert('$message');</script>";
			
			
		}else
		{
			
		}
	}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="troubleshooting.css">
        <script src="myScript.js"></script>
    </head>
<body>

    <div id="stickybar">
        <script src="myScript.js"></script>
        <a class="logo"><img src="https://upload.wikimedia.org/wikipedia/commons/6/6d/XLN-Logo.jpg" alt="image not loaded" height="100" width=aut0></a>
        <p class = "sales"> Sales: <br> 0808 302 9676 </p>
        <p class = "customer"> Customer Service: <br> 0344 880 7777</p>
    </div>

<br>
<br>
<br>
<div class="box">
    <form method = "post">
        <label for="Customer Number"><b>Customer Number</b></label>
        <br>
        <input id="text" type="text" placeholder="Customer Number" name="Customer_Key" required>
        <br>
        <br>
        <a type="forgot" id ="logintxt">Forgotten Customer Number?</a>
        <a type="unregistered" id ="logintxt" href="signup.php">Not Registered</a>
        <br>
        <br>
        <input type="Checkbox" name="chckbx">
        <label for="chckbx" >Remember me</label>
        <br>
        <br>
		<div class = "button">
        <input id="button" type="submit" value="Login">	
		</div>
    </form>
</div>

<br> <br>
<footer class="footer">
    <p id ="footer"> Footer </p>
</footer>

</div>
</body>
</html>