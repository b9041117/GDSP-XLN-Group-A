<?php

$BA_Export = array (
  'business_assurance' => '2',
);

?>