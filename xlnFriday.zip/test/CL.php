<?php

$CL_Export = array (
  'care_level' => '1',
);

?>